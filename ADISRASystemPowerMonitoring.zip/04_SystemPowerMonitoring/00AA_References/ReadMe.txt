This project is based on a previous academic project, which involved designing a renewable hybrid system for a real hospital called Nini Hospital in North Lebanon. In that project, we calculated and selected the required solar panels, generators, and batteries, and we created a full diagram showing the system connections. We also performed a simulation using Helioscope software and prepared an approximate billing for the full project.

The idea of this project is to design a SCADA system using ADISRA software for the hospital’s power system, in order to make the system as close to the real world as possible. The aim of this SCADA project was to cover all the main and essential features of a SCADA system.

We covered the basic objects such as buttons, sliders, combo boxes, images, list boxes, labels, checkboxes, radio buttons, and animations. We also covered interface menus such as GroupBox, Tab, and Screen.

Additionally, we addressed advanced objects such as Alarms/Events, MultiTagsViewer, Trends, Templates, Date-Time Picker, and Smart Messages. For charts, we included Bar, Line, and Pie charts.

Some other advanced features we implemented include: taking data from APIs, sending notifications via WhatsApp and email, implementing login and different security levels with user profiles, supporting multiple languages, connecting our data to an SQL server, maintaining alarm history, and adding historical data to trends and charts. We also added a feature to export trends and history as CSV files, with adjustable settings. The system can print reports of the current status, and we used a basic rule system to apply simple control logic.

We simulated all system values by writing code in the services and used recipes to create different ready scenarios for the system, which are adjustable.

All these features were applied in this project, and the system was optimized as much as possible to maintain a minimum number of tags and to keep things well-categorized.